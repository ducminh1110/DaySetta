# mktype.py TEXT...: print Daylight input lines ("key CODE CHAR down/up") typing TEXT on a US layout; "\n" = Return.
# Upper case and shifted symbols get "flags 20000" around them.
import sys
codes = {'a':0,'s':1,'d':2,'f':3,'h':4,'g':5,'z':6,'x':7,'c':8,'v':9,'b':11,'q':12,'w':13,'e':14,'r':15,'y':16,'t':17,
 '1':18,'2':19,'3':20,'4':21,'6':22,'5':23,'=':24,'9':25,'7':26,'-':27,'8':28,'0':29,']':30,'o':31,'u':32,'[':33,'i':34,
 'p':35,'l':37,'j':38,"'":39,'k':40,';':41,'\\':42,',':43,'/':44,'n':45,'m':46,'.':47,' ':49,'`':50,'\n':36}
shifted = {':':';','?':'/','_':'-','+':'=','!':'1','@':'2','#':'3','$':'4','%':'5','&':'7','*':'8','(':'9',')':'0','"':"'"}
for ch in ' '.join(sys.argv[1:]).replace('\\n', '\n'):
    base, shift = ch, False
    if ch in shifted: base, shift = shifted[ch], True
    elif ch.isupper(): base, shift = ch.lower(), True
    c = 13 if ch == '\n' else ord(ch)
    if shift: print('flags 20000')
    print('key %d %d down' % (codes[base], c)); print('key %d %d up' % (codes[base], c))
    if shift: print('flags 0')
