#!/bin/sh
# gdbcatch.sh APP [SIGNAL] [SECONDS]: launch a BaseSystem app (inputtest.sh), attach gdb as soon as its process
# exists, pass every signal except SIGNAL (default SIGTRAP), and when SIGNAL arrives print "F addr image+offset"
# frame-pointer backtraces of the faulting thread (symbolize with dscsym.py) plus registers.
app=$1; sig=${2:-SIGTRAP}; t=${3:-60}
name=$(basename "$app" .app)
printf "wait %s\n" $t > /tmp/gdbcatch-script.txt
cd ~/darling-port-tools
rm -rf ~/darltest/gdbcatch
(DL4_TIMEOUT=$((t + 10)) sh inputtest.sh ~/darltest/gdbcatch "$app" /tmp/gdbcatch-script.txt >/dev/null 2>&1 &)
for i in $(seq 1 400); do
	P=$(pgrep -f "^/Volumes/SystemRoot.*$name.app/Contents/MacOS" | head -1)
	[ -n "$P" ] && break
	sleep 0.05
done
[ -z "$P" ] && { echo "no process"; exit 1; }
echo "pid $P"
sudo -n timeout $t gdb -batch -nx -p $P -ex "handle all nostop noprint pass" -ex "handle $sig stop print nopass" \
	-ex "continue" -ex "info registers rip rsp rbp" -ex "python
import gdb
inf = gdb.selected_inferior()
pc = int(gdb.parse_and_eval('\$pc')); bp = int(gdb.parse_and_eval('\$rbp'))
print('RA %x' % pc)
for i in range(60):
    if bp == 0: break
    try:
        m = inf.read_memory(bp, 16).tobytes()
    except Exception:
        break
    nbp = int.from_bytes(m[:8], 'little'); ra = int.from_bytes(m[8:], 'little')
    print('RA %x' % ra)
    if nbp <= bp: break
    bp = nbp
end" 2>&1 | grep -v "^\[New\|^\[Thread\|warning" > /tmp/gdbcatch-out.txt
grep -v "^RA" /tmp/gdbcatch-out.txt | tail -8
grep "^RA" /tmp/gdbcatch-out.txt | while read _ a; do
	sudo -n awk -v a=$a 'BEGIN{x=strtonum("0x" a)} {split($1,r,"-"); s=strtonum("0x" r[1]); e=strtonum("0x" r[2]); if (x>=s && x<e) {n=split($6,p,"/"); printf "F %s %s+0x%x\n", a, p[n], x-s+strtonum("0x" $3); exit}}' /proc/$P/maps
done
