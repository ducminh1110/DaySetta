break *0x1000098b0
commands
silent
printf "loadView self=%lx\n", $r13
continue
end
break *0x100009959
commands
silent
printf "WKWebView init -> %lx\n", $rax
continue
end
break *0x10000c7ea
commands
silent
printf "validate goBackForward self=%lx weak=%lx\n", $r13, $rax
continue
end
