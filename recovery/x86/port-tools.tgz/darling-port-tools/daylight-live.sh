#!/bin/bash
# Start the CA render server + real Dock and leave both running for the web feed.
# Uses the serial-dispatch workaround added to daylight-ca for the Darling
# software rasterizer's undersized libdispatch worker stacks.
set -u
LOG=$HOME/.darling/private/tmp/daylight-ca-live.log
DOCKLOG=$HOME/darltest/dock-live.log

python3 /tmp/cleanup.py >/dev/null 2>&1 || true
darling shutdown >/dev/null 2>&1 || true
sudo -n pkill -9 -x darlingserver 2>/dev/null || true
sudo -n pkill -9 -x mldr 2>/dev/null || true
sudo -n pkill -9 -f "[d]arltest/daemons/daylight-ca" 2>/dev/null || true
sleep 3

timeout -s KILL 150 darling shell true </dev/null >/dev/null 2>&1
darling shell rm -rf /System/Applications /System/Cryptexes
darling shell ln -s /Volumes/SystemRoot/home/ubuntu/fullsystem/System/Applications /System/Applications
darling shell ln -s /Volumes/SystemRoot/home/ubuntu/fullsystem/System/Cryptexes /System/Cryptexes
sudo -n pkill -9 -f "[d]arltest/daemons/daylight-ca" 2>/dev/null || true
rm -f "$HOME/.darling/private/tmp/daylight-contexts.txt" \
      "$HOME/.darling/private/tmp/daylight-windows.txt" \
      "$HOME/.darling/private/tmp/daylight-dock-context.txt"
rm -f "$HOME/.darling/private/tmp/daylight/"context-*.png \
      "$HOME/.darling/private/tmp/daylight/screen.png"
: > "$LOG"

# Main-thread stack for scan_convert; no core dumps from the huge Darling process.
(
  ulimit -c 0
  ulimit -s 65536
  exec timeout -s KILL 7200 darling shell env \
    DYLD_SHARED_CACHE_DIR=/Volumes/SystemRoot/home/ubuntu/fullsystem/System/Library/dyld \
    DYLD_SHARED_REGION=private \
    DARLING_DYLINKER=/usr/lib/dyl4 \
    DARLING_DYLINKER_PATHS=/home/ubuntu/fullsystem \
    DAYLIGHT_RENDER_CONTEXTS=1 \
    DAYLIGHT_FOLLOW_CONTEXTS=1 \
    DAYLIGHT_COMPOSITE_LOCAL=1 \
    DAYLIGHT_RENDERER=sw \
    DAYLIGHT_SCREEN=1920x1080 \
    DAYLIGHT_MARKER=manual \
    DAYLIGHT_SERIAL_APPLY=1 \
    DAYLIGHT_CONTEXT_FILE=/private/tmp/daylight-contexts.txt \
    /Volumes/SystemRoot/home/ubuntu/darltest/daemons/daylight-ca
) > "$LOG" 2>&1 </dev/null &

sleep 4
echo "ca=$(pgrep -f '^/Volumes/SystemRoot/home/ubuntu/darltest/daemons/daylight-ca$' | wc -l)"

# Launchd's job is disabled; run the real Dock through the bridge with a long timeout.
(
  cd "$HOME"
  DL4_TIMEOUT=7200 DL4_SHELL=0 \
  DL4_ENV="DAYLIGHT_BRIDGE_CA_PROBE=1 DAYLIGHT_BRIDGE_CA_FIT=1 DAYLIGHT_BRIDGE_CA_PUBLISH=1 DAYLIGHT_BRIDGE_VERBOSE=1" \
  bash "$HOME/darling-port-tools/fsapp.sh" System/Library/CoreServices/Dock.app
) > "$DOCKLOG" 2>&1 </dev/null &

loaded=0
for i in $(seq 1 45); do
  sleep 1
  if grep -q "daylight-bridge: loaded" "$HOME/darltest/last.log" 2>/dev/null; then
    loaded=1; break
  fi
done
echo "bridge_loaded=$loaded"
echo "dock=$(pgrep -f 'bundles-fs/Dock.app/Contents/MacOS/Dock$' | wc -l)"
echo "ca_actual=$(pgrep -f '^/Volumes/SystemRoot/home/ubuntu/darltest/daemons/daylight-ca$' | wc -l)"
tail -5 "$HOME/darltest/last.log" 2>/dev/null || true
