#!/usr/bin/env python3
"""Run macOS 26.6 BaseSystem daemons (the user's own copy) under Darling's launchd.

For each daemon: write a launchd job into the prefix (~/.darling/System/Library/LaunchDaemons) that keeps Apple's
label and MachServices, runs the BaseSystem binary in place (mldr picks Darling's dyld port for it through
DARLING_DYLINKER / DARLING_DYLINKER_PATHS, so app bundles such as RecoveryOS Agent.app keep their bundle) and adds
the shared-cache environment. Run with the container stopped.
  mkdaemons.py [--undo] [--only=notifyd,cfprefsd]
"""
import os, plistlib, subprocess, sys

HOME = os.path.expanduser('~')
BS = HOME + '/basesystem'
OUT = HOME + '/darltest/daemons'
JOBS = HOME + '/.darling/System/Library/LaunchDaemons'  # the only directory Darling's launchctl bootstrap loads
PREFIX = os.environ.get('DARLING_PREFIX', '/usr/local/libexec/darling')  # lower layer of the container's rootfs
DAEMONS = [  # (plist in BaseSystem, program)
    ('System/Library/LaunchDaemons/com.apple.notifyd.plist', 'usr/sbin/notifyd'),
    ('System/Library/LaunchDaemons/com.apple.cfprefsd.xpc.daemon.plist', 'usr/sbin/cfprefsd'),
    ('System/Library/LaunchAgents/com.apple.fontd.useragent.plist',
     'System/Library/Frameworks/ApplicationServices.framework/Versions/A/Frameworks/ATS.framework/Versions/A/Support/fontd'),
    ('System/Library/LaunchDaemons/com.apple.bsd.dirhelper.plist', 'usr/libexec/dirhelper'),
    ('System/Library/LaunchAgents/com.apple.FontWorker.plist',
     'System/Library/Frameworks/ApplicationServices.framework/Versions/A/Frameworks/ATS.framework/Versions/A/Support/fontworker'),
    ('System/Library/LaunchDaemons/com.apple.coreservices.launchservicesd.plist', 'System/Library/CoreServices/launchservicesd'),
    # System XPC services of frameworks (macOS launchd creates these jobs from the bundles; Darling's does not):
    # a job dict instead of a plist path.
    ({'Label': 'com.apple.authd', 'MachServices': {'com.apple.authd': True}},
     'System/Library/Frameworks/Security.framework/Versions/A/XPCServices/authd.xpc/Contents/MacOS/authd'),
    # process assertions (WebKit keeps its WebContent/GPU/Networking processes runnable through RunningBoard;
    # without it WebKit treats them as suspended and freezes their layer trees)
    ('System/Library/LaunchDaemons/com.apple.runningboardd.plist', 'usr/libexec/runningboardd'),
    # certificate trust evaluation (HTTPS): the system daemon and the per-user agent
    ('System/Library/LaunchDaemons/com.apple.trustd.plist', 'usr/libexec/trustd'),
    ('System/Library/LaunchAgents/com.apple.trustd.agent.plist', 'usr/libexec/trustd'),
    # SCDynamicStore (diskarbitrationd and network configuration clients)
    ('System/Library/LaunchDaemons/com.apple.configd.plist', 'usr/libexec/configd'),
    # volumes for PackageKit (installer -target /) and Disk Utility: mounts as DiskArbitration disks
    ('System/Library/LaunchDaemons/com.apple.diskarbitrationd.plist', 'usr/libexec/diskarbitrationd'),
    # package installation: installer and Installer.app hand the work to these
    ('System/Library/LaunchDaemons/com.apple.installd.plist', 'System/Library/PrivateFrameworks/PackageKit.framework/Versions/A/Resources/installd'),
    ('System/Library/LaunchDaemons/com.apple.system_installd.plist', 'System/Library/PrivateFrameworks/PackageKit.framework/Versions/A/Resources/system_installd'),
    # recoveryOS services used by the CDIS apps
    ('System/Library/LaunchAgents/com.apple.recoveryos_agent.plist',
     'System/Library/CoreServices/RecoveryOS Agent.app/Contents/MacOS/RecoveryOS Agent'),
    ('System/Library/LaunchDaemons/com.apple.recoverydiagnosed.plist', 'usr/libexec/recoverydiagnosed'),
    ('System/Library/LaunchDaemons/com.apple.bosreporter.plist',
     'System/Library/PrivateFrameworks/BridgeOSInstallReporting.framework/Resources/bosreporter'),
]
ENV = {
    'DYLD_SHARED_CACHE_DIR': '/Volumes/SystemRoot' + BS + '/System/Library/dyld/',
    'DYLD_SHARED_REGION': 'private',
    'DARLING_DYLINKER': '/usr/lib/dyl4',
    'DARLING_DYLINKER_PATHS': BS,
    'DYLD_FALLBACK_LIBRARY_PATH': '/usr/lib/swift:/usr/local/lib:/usr/lib',
}

def job_file_name(plist):
    return plist['Label'] + '.plist' if isinstance(plist, dict) else os.path.basename(plist)

if '--undo' in sys.argv:
    for plist, _ in DAEMONS:
        p = os.path.join(JOBS, 'org.darling.macos26.' + job_file_name(plist))
        if os.path.exists(p):
            os.unlink(p)
    sys.exit(0)

only = [a.split('=', 1)[1] for a in sys.argv if a.startswith('--only=')]
if only:
    DAEMONS = [d for d in DAEMONS if os.path.basename(d[1]) in only[0].split(',')]

os.makedirs(OUT, exist_ok=True)
os.makedirs(JOBS, exist_ok=True)
for plist, program in DAEMONS:
    job = dict(plist) if isinstance(plist, dict) else plistlib.load(open(os.path.join(BS, plist), 'rb'))
    if isinstance(plist, dict):
        # XPC service bundles get XPC_SERVICE_NAME from launchd on macOS
        job['EnvironmentVariables'] = {'XPC_SERVICE_NAME': plist['Label']}
    args = list(job.get('ProgramArguments', [program]))
    args[0] = '/Volumes/SystemRoot' + os.path.join(BS, program)
    if program.endswith('/configd'):
        # stay in the foreground (forked, its child cannot check in with Darling's launchd) and load no plug-ins:
        # they configure interfaces and routes through kernel interfaces Linux does not have; the store is enough
        args += ['-d', '-b']
    job['ProgramArguments'] = args
    job.pop('Program', None)
    job['EnvironmentVariables'] = dict(job.get('EnvironmentVariables', {}), **ENV, OS_ACTIVITY_DT_MODE='YES')
    # os_log goes to stderr (no logd here): keep it per job
    job['StandardErrorPath'] = '/private/tmp/%s.log' % job['Label']
    job['StandardOutPath'] = '/private/tmp/%s.log' % job['Label']
    # Darling has no role accounts (_trustd...): jobs run as the Darling user. Daemons find their home through
    # HOME (runningboardd exits without one); agents get the user's.
    agent = not isinstance(plist, dict) and '/LaunchAgents/' in plist
    job['EnvironmentVariables'].setdefault('HOME', '/Users/' + os.environ.get('USER', 'ubuntu') if agent else '/var/root')
    job.pop('UserName', None)
    job.pop('GroupName', None)
    for key in ('LimitLoadToSessionType', 'POSIXSpawnType', 'PublishesEvents', 'EnablePressuredExit',
                'StartCalendarInterval', 'RunAtLoad'):
        job.pop(key, None)  # Darling's launchd has one session and no event publishers
    out = os.path.join(JOBS, 'org.darling.macos26.' + job_file_name(plist))
    plistlib.dump(job, open(out, 'wb'))
    os.chmod(out, 0o644)  # launchctl skips job files that group/others can write
    # An older copy of the same job (BaseSystem's plist copied into the Darling prefix, as some ports did) has
    # the same Label and is shadowed by this one -- or shadows it, depending on load order. Those copies still
    # name role accounts (_trustd): launchd's child calls getpwnam("_trustd"), which does not exist in Darling,
    # and exits 3 (ESRCH) before exec, so the service never starts (PackageKit's installer waited on trustd).
    for sub in ('System/Library/LaunchDaemons', 'System/Library/LaunchAgents'):
        stale = os.path.join(PREFIX, sub, job['Label'] + '.plist')
        if os.path.exists(stale):
            try:
                os.unlink(stale)
                print('removed shadowing', stale)
            except PermissionError:
                subprocess.run(['sudo', '-n', 'rm', '-f', stale], check=False)
    print('job', out, '->', args[0])
