#!/bin/bash
# Control the whole Daylight stack: window server, Core Animation render server, the real Dock,
# the web feed publisher and the noVNC web server.
#
#   daylight-stack.sh start|stop|restart|status
#
# The systemd units in daylight/systemd/ do the same thing automatically at boot; this script is the
# manual control path used while iterating.
set -u
H=$HOME
ACTION=${1:-status}

units="daylight-server daylight-ca daylight-dock daylight-publisher daylight-web"

have_systemd=$(systemctl list-unit-files daylight-server.service >/dev/null 2>&1 && echo yes || echo no)

unit_status() {
	for u in $units; do
		printf '%-20s %s\n' "$u" "$(systemctl is-active "$u" 2>/dev/null || echo unknown)"
	done
}

proc_status() {
	echo "window server : $(pgrep -f 'build-darling/daylight$' | wc -l)"
	echo "CA render srv : $(pgrep -f 'darltest/daemons/daylight-ca$' | wc -l)"
	echo "Dock          : $(pgrep -f 'bundles-fs/Dock.app/Contents/MacOS/Dock$' | wc -l)"
	echo "publisher     : $(pgrep -f 'daylight-publisher.py' | wc -l)"
	echo "websockify    : $(pgrep -f 'websockify --web /usr/share/novnc' | wc -l)"
	echo "screen.png    : $(ls -l "$H/.darling/private/tmp/daylight/screen.png" 2>/dev/null | awk '{print $6, $7, $8}')"
	echo "web status    : $(cat /usr/share/novnc/shots/status.json 2>/dev/null)"
}

case "$ACTION" in
start|restart)
	if [ "$have_systemd" = yes ]; then
		sudo -n systemctl restart $units
	else
		echo "systemd units not installed; start them with tools/install-systemd.sh"
		exit 1
	fi
	;;
stop)
	sudo -n systemctl stop $units
	;;
status)
	unit_status
	echo
	proc_status
	;;
*)
	echo "usage: $0 start|stop|restart|status"
	exit 2
	;;
esac
