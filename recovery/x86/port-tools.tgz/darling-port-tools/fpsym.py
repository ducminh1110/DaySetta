# fpsym.py < fpall output: symbolizes "F addr image+off" lines for Darling's libsystem_kernel (fat: x86_64 slice at
# file offset 0x1000) and for dyld shared cache addresses (cache .map); other lines pass through.
import re, subprocess, sys, bisect, os
LSK = '/usr/local/libexec/darling/usr/lib/system/libsystem_kernel.dylib'
MAP = os.path.expanduser('~/basesystem/System/Library/dyld/dyld_shared_cache_x86_64.map')
syms = []
for l in subprocess.run(['llvm-nm', '-n', '--arch=x86_64', LSK], capture_output=True, text=True).stdout.splitlines():
    p = l.split()
    if len(p) == 3 and p[1] in 'tT':
        syms.append((int(p[0], 16), p[2]))
keys = [s[0] for s in syms]
images = []
img = None
for l in open(MAP, errors='replace'):
    if l.startswith('/'):
        img = l.strip()
    elif '__TEXT 0x' in l:
        m = re.search(r'__TEXT (0x[0-9A-F]+) -> (0x[0-9A-F]+)', l)
        if m:
            images.append((int(m.group(1), 16), int(m.group(2), 16), img))
images.sort()
starts = [i[0] for i in images]
for line in sys.stdin:
    m = re.match(r'F ([0-9a-f]+) (\S+)\+0x([0-9a-f]+)', line)
    if m:
        a, image, off = int(m.group(1), 16), m.group(2), int(m.group(3), 16)
        if image == 'libsystem_kernel.dylib':
            i = bisect.bisect_right(keys, off - 0x1000) - 1
            line = 'F %x libsystem_kernel %s+0x%x\n' % (a, syms[i][1], off - 0x1000 - syms[i][0])
        elif image.startswith('dyld_shared_cache'):
            i = bisect.bisect_right(starts, a) - 1
            if i >= 0 and a < images[i][1]:
                line = 'F %x %s+0x%x\n' % (a, os.path.basename(images[i][2]), a - images[i][0])
    sys.stdout.write(line)
