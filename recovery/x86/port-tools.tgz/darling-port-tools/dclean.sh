#!/bin/sh
# dclean.sh: stop the Darling container and kill every leftover Darling process (orphans of earlier containers keep
# piling up and can leave "Cannot open mnt namespace file" behind). Kills by PID; never pattern-matches its own shell.
darling shutdown >/dev/null 2>&1
sleep 1
P=$(for p in /proc/[0-9]*; do e=$(readlink $p/exe 2>/dev/null); case "$e" in */mldr|*/darlingserver) echo ${p#/proc/};; esac; done)
[ -n "$P" ] && sudo -n kill -9 $P 2>/dev/null
sleep 1
