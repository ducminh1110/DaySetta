# disrange.py MACHO START END: disassemble a vm range of an x86_64 Mach-O quickly (objdump on raw bytes)
import struct, sys, subprocess, tempfile
path, start, end = sys.argv[1], int(sys.argv[2], 16), int(sys.argv[3], 16)
d = open(path, 'rb').read()
if d[:4] == b'\xca\xfe\xba\xbe':  # fat: pick the x86_64 slice
    for i in range(struct.unpack_from('>I', d, 4)[0]):
        ct, _, o, sz, _ = struct.unpack_from('>IIIII', d, 8 + 20 * i)
        if ct == 0x01000007: d = d[o:o + sz]
ncmds = struct.unpack_from('<I', d, 16)[0]; off = 32
for _ in range(ncmds):
    cmd, size = struct.unpack_from('<II', d, off)
    if cmd == 0x19:
        vmaddr, vmsize, fileoff, filesize = struct.unpack_from('<QQQQ', d, off + 24)
        if vmaddr <= start < vmaddr + vmsize:
            b = d[fileoff + start - vmaddr: fileoff + end - vmaddr]
            with tempfile.NamedTemporaryFile(suffix='.bin') as f:
                f.write(b); f.flush()
                print(subprocess.run(['objdump', '-D', '-b', 'binary', '-mi386:x86-64', '--no-show-raw-insn',
                    '--adjust-vma=%#x' % start, f.name], capture_output=True, text=True).stdout)
            break
    off += size
