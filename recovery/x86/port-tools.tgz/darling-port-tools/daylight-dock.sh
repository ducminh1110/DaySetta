#!/bin/bash
# Run the real macOS Dock in the Darling guest against the running Daylight window server and
# Core Animation render server.
#
# The Dock binary is the untouched Apple one from the full installer; only the loader environment and
# the GUI bridge are ours. `fsapp.sh` is deliberately not used here: it starts and then kills the
# window server, which takes the Dock down with it.
set -u
H=$HOME
B=/Volumes/SystemRoot/home/ubuntu/darltest/apps/daylight-bridge.dylib
ROOT=$H/fullsystem
CACHE=$ROOT/System/Library/dyld/
LOG=$H/darltest/last.log

exe=$(SHADOW_ROOT=$ROOT SHADOW_OUT=$H/darltest/bundles-fs \
	python3 "$H/darling-port-tools/shadowapp.py" System/Library/CoreServices/Dock.app) || exit 1

exec timeout -s KILL infinity darling shell sh -c "env \
  DYLD_SHARED_CACHE_DIR=/Volumes/SystemRoot$CACHE \
  DYLD_SHARED_REGION=private \
  DARLING_GUI_BRIDGE=$B \
  DYLD_FALLBACK_LIBRARY_PATH=/usr/lib/swift:/usr/local/lib:/usr/lib \
  DARLING_DYLINKER=/usr/lib/dyl4 \
  DARLING_DYLINKER_PATHS=$ROOT \
  DYLD_FALLBACK_FRAMEWORK_PATH=/Volumes/SystemRoot$H/darltest/stubs \
  DAYLIGHT_BRIDGE_CA_PROBE=1 DAYLIGHT_BRIDGE_CA_FIT=1 DAYLIGHT_BRIDGE_CA_PUBLISH=1 \
  DAYLIGHT_BRIDGE_VERBOSE=1 \
  '$exe'; echo exit=\$?" > "$LOG" 2>&1 </dev/null
