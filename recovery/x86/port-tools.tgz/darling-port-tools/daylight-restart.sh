#!/bin/bash
set -u
H=$HOME
# stop the Dock and the CA render server
pkill -9 -f "[b]undles-fs/Dock.app/Contents/MacOS/Dock" 2>/dev/null || true
pkill -9 -f "[f]sapp.sh System/Library/CoreServices/Dock.app" 2>/dev/null || true
sudo -n pkill -9 -f "[d]arltest/daemons/daylight-ca" 2>/dev/null || true
sleep 2
# window server (Daylight)
for p in $(pgrep -f "build-darling/daylight$"); do sudo -n kill -INT "$p" 2>/dev/null || true; done
sleep 2
setsid nohup timeout -s KILL 7200 darling shell env DAYLIGHT_SHELL=0 \
  /Volumes/SystemRoot/home/ubuntu/daylight/build-darling/daylight > "$H/darltest/daylight.log" 2>&1 < /dev/null &
sleep 6
# CA render server
LOG=$H/.darling/private/tmp/daylight-ca-live.log
: > "$LOG"
(
  ulimit -c 0
  ulimit -s 65536
  exec timeout -s KILL 7200 darling shell env \
    DYLD_SHARED_CACHE_DIR=/Volumes/SystemRoot/home/ubuntu/fullsystem/System/Library/dyld \
    DYLD_SHARED_REGION=private \
    DARLING_DYLINKER=/usr/lib/dyl4 \
    DARLING_DYLINKER_PATHS=/home/ubuntu/fullsystem \
    DAYLIGHT_RENDER_CONTEXTS=1 DAYLIGHT_FOLLOW_CONTEXTS=1 DAYLIGHT_COMPOSITE_LOCAL=1 \
    DAYLIGHT_RENDERER=sw DAYLIGHT_SCREEN=1920x1080 DAYLIGHT_MARKER=manual DAYLIGHT_SERIAL_APPLY=1 \
    DAYLIGHT_CONTEXT_FILE=/private/tmp/daylight-contexts.txt \
    /Volumes/SystemRoot/home/ubuntu/darltest/daemons/daylight-ca
) > "$LOG" 2>&1 </dev/null &
sleep 5
# the real Dock, with the CA canvas path on (it also runs the glass-flag forcing)
(
  cd "$H"
  DL4_TIMEOUT=7200 DL4_SHELL=0 \
  DL4_ENV="DAYLIGHT_BRIDGE_CA_PROBE=1 DAYLIGHT_BRIDGE_CA_FIT=1 DAYLIGHT_BRIDGE_CA_PUBLISH=1 DAYLIGHT_BRIDGE_CA_CANVAS=1 DAYLIGHT_BRIDGE_VERBOSE=1" \
  bash "$H/darling-port-tools/fsapp.sh" System/Library/CoreServices/Dock.app
) > "$H/darltest/dock-live.log" 2>&1 </dev/null &
sleep 35
echo "server=$(pgrep -f 'build-darling/daylight$' | wc -l) ca=$(pgrep -f '^/Volumes/SystemRoot/home/ubuntu/darltest/daemons/daylight-ca$' | wc -l) dock=$(pgrep -f 'bundles-fs/Dock.app/Contents/MacOS/Dock$' | wc -l)"
