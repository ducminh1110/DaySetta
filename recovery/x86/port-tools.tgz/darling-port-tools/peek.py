# peek.py MACHO ADDR...: for each vm address print the 8-byte pointer there (chained-fixup low bits) and the C string it points to
import struct, sys
path = sys.argv[1]; d = open(path, 'rb').read()
if d[:4] == b'\xca\xfe\xba\xbe':
    for i in range(struct.unpack_from('>I', d, 4)[0]):
        ct, _, o, sz, _ = struct.unpack_from('>IIIII', d, 8 + 20 * i)
        if ct == 0x01000007: d = d[o:o + sz]
segs = []; off = 32
for _ in range(struct.unpack_from('<I', d, 16)[0]):
    cmd, size = struct.unpack_from('<II', d, off)
    if cmd == 0x19:
        segs.append(struct.unpack_from('<QQQQ', d, off + 24))
    off += size
def fo(a):
    for v, vs, f, fs in segs:
        if v <= a < v + vs: return f + a - v
def cstr(a):
    o = fo(a); return d[o:d.index(b'\0', o)].decode(errors='replace') if o is not None else None
for a in sys.argv[2:]:
    a = int(a, 16); o = fo(a); p = struct.unpack_from('<Q', d, o)[0]
    t = 0x100000000 + (p & 0xffffffff) if p >> 63 == 0 else None
    print(hex(a), hex(p), hex(t) if t else '', cstr(t) if t else '', '| as str:', cstr(a)[:60] if cstr(a) else '')
