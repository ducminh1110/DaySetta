#!/bin/sh
# gdbrun.sh APP SECONDS GDBCMDFILE: launch a BaseSystem app (inputtest.sh), attach gdb as soon as its process exists,
# pass all signals and run the gdb commands in GDBCMDFILE (breakpoints with "commands ... continue end"), then continue.
app=$1; t=${2:-60}; cmds=$3
name=$(basename "$app" .app)
printf "wait %s\n" $t > /tmp/gdbrun-script.txt
cd ~/darling-port-tools
rm -rf ~/darltest/gdbrun
(DL4_TIMEOUT=$((t + 10)) sh inputtest.sh ~/darltest/gdbrun "$app" /tmp/gdbrun-script.txt >/dev/null 2>&1 &)
for i in $(seq 1 400); do
	P=$(pgrep -f "^/Volumes/SystemRoot.*$name.app/Contents/MacOS" | head -1)
	[ -n "$P" ] && break
	sleep 0.05
done
[ -z "$P" ] && { echo "no process"; exit 1; }
echo "pid $P"
sudo -n timeout $t gdb -batch -nx -p $P -ex "handle all nostop noprint pass" -ex "set breakpoint pending on" \
	-x "$cmds" -ex "continue" 2>&1 | grep -v "^\[New\|^\[Thread\|warning\|^\[Inferior"
